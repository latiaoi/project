package com.pojo;

public class Goods {
    private int gid;
    private String gname;
    private String gprice;
    private String ghome;
    private String gimg;


    public Goods() {
    }

    public Goods(String gname, String gprice, String ghome, String gimg) {
        this.gname = gname;
        this.gprice = gprice;
        this.ghome = ghome;
        this.gimg = gimg;
    }

    public int getGid() {
        return gid;
    }

    public void setGid(int gid) {
        this.gid = gid;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getGprice() {
        return gprice;
    }

    public void setGprice(String gprice) {
        this.gprice = gprice;
    }

    public String getGhome() {
        return ghome;
    }

    public void setGhome(String ghome) {
        this.ghome = ghome;
    }

    public String getGimg() {
        return gimg;
    }

    public void setGimg(String gimg) {
        this.gimg = gimg;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "gid=" + gid +
                ", gname='" + gname + '\'' +
                ", ghome='" + ghome + '\'' +
                ", gimg='" + gimg + '\'' +
                ", gprice=" + gprice +
                '}';
    }
}
