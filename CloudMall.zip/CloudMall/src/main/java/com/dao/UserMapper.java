package com.dao;

import com.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    //通过用户名查找用户是否存在(存在返回true 不存在返回false)
    boolean findUser(String username);
    //用户名密码查找
    User getUser(Map<String,Object> map);
    //添加新用户
    int addUser(User user);
    //通过id修改用户信息
    boolean upDateUser(Map<String,Object> map);
    //通过id删除用户
    boolean delUser(String id);
    //查询总的用户记录条数
    int countUser();
    //查询指定页的Pagesize条记录
    List<User> pageUser(@Param("start") int start,@Param("Pagesize") int Pagesize);

    List<User> listByUser(String username);
}
