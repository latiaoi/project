package com.dao;

import com.pojo.Goods;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface GoodsMapper {
    //查看商品表
    List<Goods> getGoodsList();
    //添加新商品
    int addGoods(Goods goods);
    //通过gid修改商品信息
    boolean upDateGoods(Map<String,Object> map);
    //通过gid删除商品
    boolean delGoods(String id);
    //查询总的商品记录条数
    int countGoods();
    //查询指定页的Pagesize条记录
    List<Goods> pageGoods(@Param("start") int start, @Param("Pagesize") int Pagesize);
}
