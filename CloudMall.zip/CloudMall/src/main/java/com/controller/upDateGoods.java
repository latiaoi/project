package com.controller;

import com.dao.GoodsMapper;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/upDateGoods")
public class upDateGoods extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String gid=request.getParameter("gId");
        String gname=request.getParameter("gName");
        String gprice=request.getParameter("gPrice");
        String ghome=request.getParameter("gHome");
        String gimg=request.getParameter("gImg");
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        GoodsMapper mapper=sqlSession.getMapper(GoodsMapper.class);
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("gid",gid);
        map.put("gname",gname);
        map.put("gprice",gprice);
        map.put("ghome",ghome);
        map.put("gimg",gimg);
        mapper.upDateGoods(map);
        sqlSession.commit();
        //关闭SqlSession
        sqlSession.close();
        PrintWriter out=response.getWriter();
        out.print(true);
        out.flush();
        out.close();
    }
}
