package com.controller;

import com.dao.GoodsMapper;
import com.pojo.Goods;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/setGoods")
public class setGoods  extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String gname=request.getParameter("gName");
        String gprice=request.getParameter("gPrice");
        String ghome=request.getParameter("gHome");
        String gimg=request.getParameter("gImg");
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        GoodsMapper mapper=sqlSession.getMapper(GoodsMapper.class);
        mapper.addGoods(new Goods(gname,gprice,ghome,gimg));

        sqlSession.commit();
        //关闭SqlSession
        sqlSession.close();
        PrintWriter out=response.getWriter();
        out.print(true);
        out.flush();
        out.close();
    }
}
