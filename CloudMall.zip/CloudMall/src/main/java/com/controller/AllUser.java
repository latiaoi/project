package com.controller;

import com.dao.UserMapper;
import com.pojo.User;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet("/alluser")
public class AllUser  extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);

        int page=1;//页面当前页
        int count=mapper.countUser();//查询总记录条数
        String str_page=request.getParameter("page");//得到传过来的当前页
        int Pagesize=10;//一页可显示条数
        int Pagenumber=(count/Pagesize)+1;//总的页面数
        int Endpage=Pagenumber;//最后一页

        if (str_page!=null) {
            //将页转换整型判断其大小
            int pag=Integer.parseInt(str_page);
            //当大于零，将传过来的pag值赋给当前页page
            if (pag==0) {
                page=1;

            }else if (pag>Endpage){
                page=Endpage;
            }else {
                page=pag;
            }
        }
        int start=(page-1)*Pagesize;//需要查询的起始点
        List<User> user=mapper.pageUser(start,Pagesize);//查询页内容

        //关闭SqlSession
        sqlSession.close();
        request.setAttribute("user", user);//用户记录
        request.setAttribute("page", page);//页码
        request.setAttribute("Endpage",Endpage);//最后一页
        request.setAttribute("Pagenumber", Pagenumber);//总的页面数
        request.getRequestDispatcher("UserManage.jsp").forward(request,response);
    }
}
