package com.controller;

import com.dao.UserMapper;
import com.pojo.User;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/login")
public class UserLogin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置字符集
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        String username = request.getParameter("user");
        String password = request.getParameter("pwd");

        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);
        Map<String,Object> map=new HashMap<String,Object>();

        map.put("username",username);
        map.put("password",password);

        mapper.getUser(map);
        User a= mapper.getUser(map);
        //关闭SqlSession
        sqlSession.close();
        //用session来管理用户会话登录
        HttpSession session=request.getSession();
        if (a==null){
            System.out.println("账号或密码输入错误!");
            String msg="账号或密码输入错误!";
            request.setAttribute("msg",msg);
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }else if (a.getUsername().equals("admin") && a.getPassword().equals("admin")){
            System.out.println(a.getUsername()+"管理员登录成功!");
            //用户名登陆成功，把用户放到session中去
            session.setAttribute("USER_NAME", a.getUsername());
            request.getRequestDispatcher("guanli.jsp").forward(request, response);
        }else {
            System.out.println(a.getUsername()+"用户登录成功!");
            session.setAttribute("USER_NAME", a.getUsername());
//            req.getRequestDispatcher("index2.jsp").forward(req, resp);
            response.sendRedirect("index2.jsp");
        }
    }
}

