package com.controller;

import com.dao.UserMapper;
import com.pojo.User;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
@WebServlet("/setUser")
public class setUser extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String username=request.getParameter("uName");
        String password=request.getParameter("uPwd");
        String email=request.getParameter("uEmail");
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);
        mapper.addUser(new User(username,password,email));

        sqlSession.commit();
        //关闭SqlSession
        sqlSession.close();
        PrintWriter out=response.getWriter();
        out.print(true);
        out.flush();
        out.close();
    }
}
