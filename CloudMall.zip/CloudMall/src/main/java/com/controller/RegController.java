package com.controller;

import com.dao.UserMapper;
import com.pojo.User;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServlet;

@Controller
public class RegController  extends HttpServlet {
    @RequestMapping(value="/reg")
    public  String reg(String user, String pwd, String email){
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);
        mapper.addUser(new User(user,pwd,email));
        System.out.println("注册成功!用户名:"+user+" 密码:"+pwd+" 邮箱:"+email);
        sqlSession.commit();
        //关闭SqlSession
        sqlSession.close();
        return "redirect:login.jsp";
    }
}