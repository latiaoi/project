package com.controller;

import com.dao.UserMapper;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/CheckUserServlet")
public class CheckUserServlet extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        System.out.println("Ajax请求成功");
        String username=request.getParameter("username");
        PrintWriter out=response.getWriter();
        out.print(isUserExists(username));
        out.flush();
        out.close();
    }

    private boolean isUserExists(String username) {
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);
        String a=username;
        mapper.findUser(a);
        sqlSession.commit();

        if(mapper.findUser(a)==true){
            System.out.println("用户:"+a+" 已注册");
            //关闭SqlSession
            sqlSession.close();
            return true;
        }else {
            System.out.println("用户:"+a+" 可注册");
            //关闭SqlSession
            sqlSession.close();
            return false;
        }
    }
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request,response);
    }
}
