package com.controller;

import com.dao.GoodsMapper;
import com.pojo.Goods;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/delGoods")
public class delGoods extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        String id=request.getParameter("gId");
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        GoodsMapper mapper=sqlSession.getMapper(GoodsMapper.class);
        mapper.delGoods(id);

        sqlSession.commit();
        //关闭SqlSession
        sqlSession.close();
        PrintWriter out=response.getWriter();
        out.print(true);
        out.flush();
        out.close();
    }
}
