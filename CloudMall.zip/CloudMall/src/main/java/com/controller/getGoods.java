package com.controller;

import com.dao.GoodsMapper;
import com.pojo.Goods;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/getgoods")
public class getGoods extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        GoodsMapper mapper=sqlSession.getMapper(GoodsMapper.class);
        List<Goods> goodsList=mapper.getGoodsList();

        //关闭SqlSession
        sqlSession.close();
        request.setAttribute("goods",goodsList);
        request.getRequestDispatcher("allgoods.jsp").forward(request,response);
    }
}
