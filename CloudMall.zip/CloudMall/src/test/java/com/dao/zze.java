package com.dao;

import com.pojo.User;
import com.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class zze {
    @Test
    public void li(){
        //第一步：获取SqlSession对象
        SqlSession sqlSession= MybatisUtils.getSqlSession();
        //执行sql getMapper
        UserMapper mapper=sqlSession.getMapper(UserMapper.class);
        String username="小";
        List<User> xx=mapper.listByUser(username);
        System.out.println(xx);
    }
}
